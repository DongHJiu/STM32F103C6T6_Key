#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Key.h"
#include "LED.h"

int main(){
	Key_Init();
	LED_Init();
	while(1){		
	if(KeyOnce()==1){
		LED_Data(1);
	}
	else{LED_Data(0);}
	}	
}
