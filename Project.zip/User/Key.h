#ifndef __Key_H
#define __Ket_H

void Key_Init(void);
int KeyOnce(void);
int KeyKeep(void);


#endif
